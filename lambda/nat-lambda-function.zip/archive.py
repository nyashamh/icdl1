import os
import shutil 
from os import path
from zipfile import ZipFile
from os import path
from shutil import make_archive

def main():
    if path.exists("nat-lambda-function.py"):
        src = path.realpath("nat-lambda-function.py");

    root_dir,tail = path.split(src)
    shutil.make_archive("nat-lambda-function","zip",root_dir)

if __name__=="__main__":
    main()